The file valiData.txt includes five columns, 1st is frequency in Hz, 2nd is Re(S11) for the open-termination line, 3rd is Im(S11) for the open-termination line, 4th is Re(S11) for the short-termination line and 5th is Im(S11) for the short-termination line.

The line has the following physical parameters:

W = 4mm
L = 75mm
h = 1.2mm
t = 50um
Trace made of copper
